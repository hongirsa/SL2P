
#include<vector>
#include <stdlib.h>
#include <string>

using namespace std;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Description: Class convexhull to access parameters Step, tolerance, Extreme and Grid
//
// Revision history:    2020-Jan-10    Gang Hong    Initial Creation
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Convexhull
{
public:  
    Convexhull(const char *filepath);  // initializing a convex hull through reading a file
//	vector<vector<float>> getGrid();
//	void setGrid(vector<float> temp);
	int getStep();
	void setStep(int temp);
	float getTolerance();
	void setTolerance(float temp);
	vector<vector<float>> getExtreme();
	void setExtreme(vector<float>);
	void loadParams(const char* filepath);
	//void calUCLref(vector<vector<float>>);
	vector<long long> getUCLref();
	void setUCLref(vector<long long> temp);
      
private:	
	vector<vector<float> > extreme2D; //2 dimension
	//vector<vector<float> > grid2D;//2 dimension
    int step;
    float tolerance;
	vector<long long> UCL_ref;	

};

