// BioPhy.cpp 
//
#define _CRT_SECURE_NO_WARNINGS  // removing warning for class time_t

#include<iostream>
#include <algorithm>
#include <stdio.h>
#include <string>
#include <sstream>    
#include<vector>
#include <fstream>
#include <iterator>
#include <ctime>    
#include "BioPhy.h"
#include <functional>
#include <math.h> 
#define PI 3.14159265

using namespace std;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Description: SL2P main functions
//
// Revision history:    2020-Jan-10  Gang Hong   initial creation
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// function to calculate solar and sensor angles based on tile index
//Output: two solar angles and two empty sensor angles
void calculateAngles(size_t rows, //  height of image cube
	size_t cols, // width of image cube
	string path, // the path name without including file name
	string startName, //the starting part of the file name 
	string year  //the year of the data, input format like "2016"
);

// function to calculate BioPhysical parameters based on input imagery bands
//Output: all biophysical parameters and their corresponding flag quality indicator
vector<vector<vector<float>>>  CalBioPhy(short* ptrBand[], // image cubes of surface reflectance and angles
	BioPhy tempBioPhy, // an object of class BioPhy 
	int rows, // height of image cube
	int cols, //width of image cube
	int fileNum // number of surface reflectance bands plus the number of angel files
);

///// function to calculate biophysical parameters and flag based on the input pixels 
//output: each biophysical parameter and its corresponding flag 
vector<float> CalNeuralNetFlagOutput(const vector<float>& tempInput, // vector of per pixel
	Network tempNet, // an object of neural network 
	BioVARboundingbox tempBioBARboudingbox, // an object of BioVARboundingbox
	int tempFlag // flag for input data only
);


//// function to save the result to file
template <class T>
void outputToFile(const vector<vector<T>>& outputFile,  /// two dimension vector for the oupput file
	int rows,// height of image cube
	int cols, //width of image cube
	const char* filepath //output file name
);

/// function to calculate uncertainty biophysical parameters based on the input pixels 
float CalunNeuralNetOutput(const vector<float>& tempInput, // the input of pixel vector 
	Network tempNet // the input of neural network
);

int main() {
	size_t rows = 5000; //  the height of the image
	size_t cols = 5000; // the width of the image 

	string path = "C:/Tile43/";
	string startName = "Tile43_";

	//Initialize an BioPhy object
	string coefficentListfile = path + "coefficients/Fileslist.txt";
	BioPhy ls8Biophy(coefficentListfile.c_str());
	//create a log file
	string outputLogfile = path + startName + "log.txt";
	ofstream outfileLog(outputLogfile, ios::out | ios::trunc);
	outfileLog << path << endl;

	outfileLog << "Start calculating angles" << endl;
	calculateAngles(30000, 30000, path, startName, "2016");
	outfileLog << "finish calculating angles" << endl;

	vector<string> endNames = { "cch3","cch4","cch5","cch6","cch7","solar_zenith","sensor_zenith","solar_azimuth","sensor_azimuth" };
	size_t fileNum = endNames.size();
	vector<string> fullfileName(fileNum);
	int i = 0;
	outfileLog << "Input files:" << endl;
	while (i < fileNum) {
		fullfileName[i] = path + startName + endNames[i] + ".raw";
		outfileLog << fullfileName[i] << endl; //output the full name to the log file
		i++;
	}

	short** ptrImage = new short* [9];
	for (int i = 0; i < 9; i++)
		ptrImage[i] = new short[rows * cols];

	i = 0;
	while (i < fileNum) {
		ifstream imageData(fullfileName[i], ios::in | ios::binary);// open file		
		imageData.read((char*)ptrImage[i], rows * cols * sizeof(short));//read file
		i++;
	}
	//calcuate time
	time_t my_time1 = time(NULL);
	outfileLog << "Start processing Biophysical parameters time:" << endl;
	outfileLog << ctime(&my_time1) << endl;

	// calculate biophysical parameter and flag indicatior based on input bands
	vector<vector<vector<float>>> outputResults;
	outputResults = CalBioPhy(ptrImage, ls8Biophy, rows, cols, fileNum);

	for (int i = 0; i < 9; i++)
		delete[] ptrImage[i];
	delete[] ptrImage;

	/////**********************************************Output neural network resutls and flag results*********************************************************/////////////
	vector<string> bio = { "FCOVER","FAPAR","LAI","LAI_Cab","LAI_Cw","FCOVER_uncertainty","FAPAR_uncertainty","LAI_uncertainty","LAI_Cab_uncertainty","LAI_Cw_uncertainty","flag_FCOVER","flag_FAPAR","flag_LAI","flag_LAI_Cab","flag_LAI_Cw" };
	string temp_str;
	outfileLog << "Output file names:" << endl;
	for (int m = 0; m < bio.size(); m++)
	{
		temp_str = path + startName + bio[m] + ".raw";
		outfileLog << temp_str << endl;
		outputToFile(outputResults[m], rows, cols, temp_str.c_str());
	}
	////calculate time
	outfileLog << "Finish processing Biophysical parameter time:" << endl;
	time_t my_time2 = time(NULL);
	outfileLog << ctime(&my_time2) << endl;
	outfileLog.close();
}


/// function to calculate biophysical parameters and flag based on the input pixels 
vector<float> CalNeuralNetFlagOutput(const vector<float>& tempInput, Network tempNet, BioVARboundingbox tempBioBARboudingbox, int tempFlag)
{
	vector<float> result(2);
	float tempVal;
	size_t output_thresholded_to_min = 0;
	size_t output_thresholded_to_max = 0;
	size_t	 output_too_low = 0;
	size_t	 output_too_high = 0;
	size_t flag_output;

	float outOffset = tempNet.getoutOffset(); // outOffset from class network
	float outSlope = tempNet.getoutSlope(); //outSlope from class network

	float tempPmin = tempBioBARboudingbox.getpMin(); //pMin from class BioBARboudingbox
	float tempPmax = tempBioBARboudingbox.getpMax(); //pMax from class BioBARboudingbox
	float temptolerance = tempBioBARboudingbox.getToleranceBio(); //tolerance from class BioBARboudingbox

	tempVal = tempNet.computeOutput(tempInput).get(0, 0);  /// neual network output				
	try
	{
		tempVal = (tempVal - outOffset) / outSlope;// rescale output
	}

	catch (exception& e)
	{
		cout << e.what() << '\n';
	}
	////////************************** flags calculation********************************************************///////////////
	if (tempVal<tempPmin && tempVal>tempPmin - temptolerance)
	{
		output_thresholded_to_min = 1;//output_thresholded_to_min
		tempVal = tempPmin;
	}
	if (tempVal > tempPmax && tempVal < tempPmax + temptolerance)
	{
		output_thresholded_to_max = 1;//output_thresholded_to_max
		tempVal = tempPmax;
	}
	if (tempVal < tempPmin - temptolerance)
		output_too_low = 1;//output_too_low
	if (tempVal > tempPmax + temptolerance)
		output_too_high = 1; //output_too_high

	//output of flag quality indicator for the final output
	flag_output = tempFlag + 2 * output_thresholded_to_min + 4 * output_thresholded_to_max + 8 * output_too_low + 16 * output_too_high;

	////////**************************end of flags calculation****************************************************///////////////
	result[0] = tempVal;
	result[1] = flag_output;
	return result;
}

/// function to calculate uncertatinty biophysical parameters based on the input pixels 
float CalunNeuralNetOutput(const vector<float>& tempInput, Network tempNet)
{
	float tempVal;
	float outOffset = tempNet.getoutOffset(); // outOffset from class network
	float outSlope = tempNet.getoutSlope(); //outSlope from class network

	tempVal = tempNet.computeOutput(tempInput).get(0, 0);  /// neual network output

	try
	{
		tempVal = (tempVal - outOffset) / outSlope;  //rescale output
	}

	catch (exception& e)
	{
		cout << e.what() << '\n';
	}
	return tempVal;
}



// function to save the result to file
template <class T>
void outputToFile(const vector<vector<T>>& outputFile, int rows, int cols, const char* filepath)
{

	try
	{
		ofstream saveFile(filepath, ios::out | ios::binary);
		for (int i = 0; i < outputFile.size(); i++)
		{
			if (outputFile[i].size() > 0)
			{
				saveFile.write(reinterpret_cast<const char*> (&outputFile[i][0]), outputFile[i].size() * sizeof(T));
			}
		}
	}
	catch (exception& e)
	{
		cout << e.what() << '\n';
	}
}
/// function to calculate BioPhysical parameters based on input imagery bands
vector<vector<vector<float>>>  CalBioPhy(short* ptrBand[], BioPhy tempBioPhy, int rows, int cols, int fileNum)
{
	vector<vector<vector<float>>> output_result;  // for storing output results

	//// temporary varialbe for storing parameters from  neural network
	vector<vector<float>> inpSlope;
	vector<vector<float>> inpOffset;

	//load neuarl network parameters
	inpSlope = tempBioPhy.getinpSlope();
	inpOffset = tempBioPhy.getinpOffset();

	//*loading convexhull parameters
	float tolerance = tempBioPhy.getTolerance();
	vector<vector<float>> extreme2d = tempBioPhy.getExtreme();
	vector<long long> UCL_ref = tempBioPhy.getUCLref();

	float temp;
	long long tempSum;
	vector<float> tempVec(fileNum - 1); // for storing temporary vector
	vector<float> tempunVec(fileNum - 1); // for storing uncertainties temporary vector
	vector<float> tempunVec1(fileNum - 1);// for changing order for preparing uncertainties input

	size_t flag;
	int h, w; // index for two dimension

	float tempCal;
	float tempunCal;
	short tempCal1;

	vector<vector<float>> output_LAI(rows, vector<float>(cols));//  storing the output of biophysical parameter-LAI
	vector<vector<float>> output_LAI_Cw(rows, vector<float>(cols));//  storing the output of biophysical parameter-LAI_Cw
	vector<vector<float>> output_LAI_Cab(rows, vector<float>(cols));//  storing the output of biophysical parameter-LAI_Cab
	vector<vector<float>> output_FCOVER(rows, vector<float>(cols));//  storing the output of biophysical parameter-FCOVER
	vector<vector<float>> output_FAPAR(rows, vector<float>(cols));//  storing the output of biophysical parameter-FAPAR

	vector<vector<float>> output_unLAI(rows, vector<float>(cols));//  storing the output of biophysical parameter-LAI
	vector<vector<float>> output_unLAI_Cw(rows, vector<float>(cols));//  storing the output of biophysical parameter-LAI_Cw
	vector<vector<float>> output_unLAI_Cab(rows, vector<float>(cols));//  storing the output of biophysical parameter-LAI_Cab
	vector<vector<float>> output_unFCOVER(rows, vector<float>(cols));//  storing the output of biophysical parameter-FCOVER
	vector<vector<float>> output_unFAPAR(rows, vector<float>(cols));//  storing the output of biophysical parameter-FAPAR

	vector<vector<float>> flag_output_LAI(rows, vector<float>(cols, 0));//  storing the output of flag indicaotor of biophysical parameter-LAI
	vector<vector<float>> flag_output_LAI_Cw(rows, vector<float>(cols, 0));//  storing the output of flag indicaotor of biophysical parameter-LAI_Cw
	vector<vector<float>> flag_output_LAI_Cab(rows, vector<float>(cols, 0));//  storing the output of flag indicaotor of biophysical parameter-LAI_Cab
	vector<vector<float>> flag_output_FAPAR(rows, vector<float>(cols, 0));//  storing the output of flag indicaotor of biophysical parameter-FAPAR
	vector<vector<float>> flag_output_FCOVER(rows, vector<float>(cols, 0));//  storing the output of flag indicaotor of biophysical parameter-FCOVER

	vector<float> tempResult1d(2); // for stoing per pixel one biophysical parameters
	float tempunResult;
	vector<vector<float>> tempResult2d(5, vector<float>(3));// for storing per pixel all biophysical parameters (5) , biophysical, uncertainties, flag

	float tempVal_LAI, tempVal_LAI_Cab, tempVal_LAI_Cw, tempVal_FCOVER, tempVal_FAPAR; // temporal varible for storing single biophyical paramter
	float tempVal_unLAI, tempVal_unLAI_Cab, tempVal_unLAI_Cw, tempVal_unFCOVER, tempVal_unFAPAR; // temporal varible for storing single biophyical paramter

	for (int j = 0; j < rows * cols; j++)
	{
		h = (int)j / cols;  // index for two dimension
		w = j % cols; // index for two dimension

		for (int m = 0; m < 5; m++)  // 5 biophysical parameters
		{
			tempSum = 0;
			for (int i = 0; i < fileNum - 1; i++) // row set to 1
			{
				if (i < 5)  /// "cch3","cch4","cch5","cch6","cch7" divided by 10000 //-9999 Nodata
				{
					temp = ptrBand[i][j] / 10000.0; /// divide by 10000 for Landsat reflectance 

					tempCal = temp * inpSlope[m][i] + inpOffset[m][i]; //for biophysical parameter, inslope and inpoffest is the same for all biophysical parameter,use the first one would be fine.
					/// for uncertaintie, coefficdents was gotten based on input sequence 
					///"solar_zenith","sensor_zenith","|solar_azimuth-sensor_azimuth|","cch3","cch4","cch5","cch6","cch7",
					// the following calculation is for "cch3","cch4","cch5","cch6","cch7"
					tempunCal = temp * inpSlope[m + 5][i + 3] + inpOffset[m + 5][i + 3]; //for uncertainty
					///***********************calculate flags*************************************
					if (m == 0)  //all biophysical parameters shared one input flag
					{
						try
						{
							tempCal1 = ceil((temp - extreme2d[0][i]) / (extreme2d[1][i] - extreme2d[0][i]) * 10.0);  //10 is the step
						}
						catch (exception& e)
						{
							cout << e.what() << '\n';
						}

						if (tempCal1 > 99 || tempCal1 < 0)
						{
							tempCal1 = 0;//tempCal1 = 99;
						}
						tempSum = tempSum + tempCal1 * pow(100, i);
					}
					/**********************************************************************************/
				}
				else if (i > 4)// "solar_zenith","sensor_zenith","abs(solar_azimuth-sensor_azimuth)"
				{
					if (i == (fileNum - 2))
						temp = abs(ptrBand[i + 1][j] - ptrBand[i][j]) / 100.0; //divide by 100 for angle parameters				
					else
						temp = ptrBand[i][j] / 100.0; //divide by 100 for angle parameters
					temp = cos(temp * PI / 180.0);
					tempCal = temp * inpSlope[m][i] + inpOffset[m][i];//for biophysical parameter
				/// for uncertaintie, coefficdents was gotten based on input sequence 
					///"solar_zenith","sensor_zenith","|solar_azimuth-sensor_azimuth|","cch3","cch4","cch5","cch6","cch7",
					// the following calculation is for "solar_zenith","sensor_zenith","|solar_azimuth-sensor_azimuth|"
					tempunCal = temp * inpSlope[m + 5][i - 5] + inpOffset[m + 5][i - 5]; //for uncertainty
				}
				else
				{
					tempCal = -9999.0;
					tempunCal = -9999.0;
				}
				tempVec[i] = tempCal;
				tempunVec[i] = tempunCal;
			}

			if (m == 0)////all biophysical parameters shared one input flag
			{
				//UCL_ref has been sorted for fast comparison, binary_search for sorted interger vector
				if (binary_search(UCL_ref.begin(), UCL_ref.end(), tempSum))
				{
					flag = 0;
				}
				else
					flag = 1;
			}

			/////*****************end of judging elements of UCL in UCL_ref***************************************************************/////

			auto result = min_element(begin(tempVec), end(tempVec)); ///find the minimum one of each input row
			// uncertainty, the input order: three angles first followed by surface reflectance	
			for (int n = 0; n < 3; n++)
				tempunVec1[n] = tempunVec[n + 5];

			for (int n = 0; n < 5; n++)
				tempunVec1[n + 3] = tempunVec[n];

			//exclude no data
			if (*result != -9999.0) {

				// calculate one biophysical parameter
				tempResult1d = CalNeuralNetFlagOutput(tempVec, tempBioPhy.net[m], tempBioPhy.bioVAR[m], flag);  //two outputs: one biophysical, one flag
				//	calculate uncertainty neural network2*******************************************" << endl;
				tempunResult = CalunNeuralNetOutput(tempunVec1, tempBioPhy.unNet[m]);//only one uncertainty output for one biophysical

				//put all biophysical parameter and corresponding flag indicator in a two dimension vector, for each dimension: [0] biophysical parameter [1] flag
				//plus uncertanties accosiated with each biophysical parameter 			
				tempResult2d[m][0] = tempResult1d[0];
				tempResult2d[m][1] = tempResult1d[1];
				tempResult2d[m][2] = tempunResult;

				//////////**************************end of flags calculation****************************************************///////////////
				// assign results for final output
				tempVal_FCOVER = tempResult2d[0][0];
				flag_output_FCOVER[h][w] = tempResult2d[0][1];
				tempVal_unFCOVER = tempResult2d[0][2];
				tempVal_FAPAR = tempResult2d[1][0];
				flag_output_FAPAR[h][w] = tempResult2d[1][1];
				tempVal_unFAPAR = tempResult2d[1][2];
				tempVal_LAI = tempResult2d[2][0];
				flag_output_LAI[h][w] = tempResult2d[2][1];
				tempVal_unLAI = tempResult2d[2][2];
				tempVal_LAI_Cab = tempResult2d[3][0];
				flag_output_LAI_Cab[h][w] = tempResult2d[3][1];
				tempVal_unLAI_Cab = tempResult2d[3][2];
				tempVal_LAI_Cw = tempResult2d[4][0];
				flag_output_LAI_Cw[h][w] = tempResult2d[4][1];
				tempVal_unLAI_Cw = tempResult2d[4][2];

			}// for no data case
			else
			{
				tempVal_LAI_Cw = -9999.0;
				tempVal_unLAI_Cw = -9999.0;
				flag_output_LAI_Cw[h][w] = flag;
				tempVal_LAI_Cab = -9999.0;
				tempVal_unLAI_Cab = -9999.0;
				flag_output_LAI_Cab[h][w] = flag;
				tempVal_LAI = -9999.0;
				tempVal_unLAI = -9999.0;
				flag_output_LAI[h][w] = flag;
				tempVal_FAPAR = -9999.0;
				tempVal_unFAPAR = -9999.0;
				flag_output_FAPAR[h][w] = flag;
				tempVal_FCOVER = -9999.0;
				tempVal_unFCOVER = -9999.0;
				flag_output_FCOVER[h][w] = flag;
			}

			output_LAI[h][w] = tempVal_LAI;
			output_LAI_Cw[h][w] = tempVal_LAI_Cw;
			output_LAI_Cab[h][w] = tempVal_LAI_Cab;
			output_FAPAR[h][w] = tempVal_FAPAR;
			output_FCOVER[h][w] = tempVal_FCOVER;

			output_unLAI[h][w] = tempVal_unLAI;
			output_unLAI_Cw[h][w] = tempVal_unLAI_Cw;
			output_unLAI_Cab[h][w] = tempVal_unLAI_Cab;
			output_unFAPAR[h][w] = tempVal_unFAPAR;
			output_unFCOVER[h][w] = tempVal_unFCOVER;
		}
	}
	output_result.push_back(output_FCOVER);
	output_result.push_back(output_FAPAR);
	output_result.push_back(output_LAI);
	output_result.push_back(output_LAI_Cab);
	output_result.push_back(output_LAI_Cw);

	output_result.push_back(output_unFCOVER);
	output_result.push_back(output_unFAPAR);
	output_result.push_back(output_unLAI);
	output_result.push_back(output_unLAI_Cab);
	output_result.push_back(output_unLAI_Cw);

	output_result.push_back(flag_output_FCOVER);
	output_result.push_back(flag_output_FAPAR);
	output_result.push_back(flag_output_LAI);
	output_result.push_back(flag_output_LAI_Cab);
	output_result.push_back(flag_output_LAI_Cw);

	return output_result;
}

//function to calculate solarand sensor angles based on tile index
void calculateAngles(size_t rows, size_t cols, string path, string startName, string year)
{
	// a stuture to store ID, aziumth, elevation angle
	struct ind {
		int ID;
		float solarAzimuth;
		float solarElev;
	};
	vector<float> tempVec;
	string tmp;
	vector <struct ind> index; //vetor to store index , azimuth, zenith
	vector<int> sceneID;// a int vector to store index only for fast searching purpose
	struct ind tempStruct;
	short* indexValue = new short[rows * cols]; //for storing tille index
	short* angleSolarAzm = new short[rows * cols]; //for storing solar azimuth angle 
	short* angleSolarZen = new short[rows * cols]; //for storing solar zenith angle

	// genenrate two empty sensor angle files: azimuth and azimuth
	string outputSensor_zenith = path + startName + "sensor_zenith.raw";
	ofstream outfile1(outputSensor_zenith, ios::binary | ios::out | ios::trunc);
	outfile1.write(reinterpret_cast<char*>(angleSolarZen), sizeof(short) * rows * cols);
	outfile1.close();
	string outputSensor_azimuth = path + startName + "sensor_azimuth.raw";
	ofstream outfile2(outputSensor_azimuth, ios::binary | ios::out | ios::trunc);
	outfile2.write(reinterpret_cast<char*>(angleSolarZen), sizeof(short) * rows * cols);
	outfile2.close();

	// open title index file
	string inputIndex = path + startName + "ind.raw";
	//cout << inputIndex << endl;
	ifstream indexData(inputIndex, ios::in | ios::binary);
	//read title index file
	indexData.read((char*)indexValue, rows * cols * sizeof(short));

	const char delim = ',';
	string inputList = path + "lsit" + year + "_angl.txt";
	//cout << inputList << endl;
	ifstream inFile(inputList);
	int m;
	string str;
	// the following seciton to read index file and generate a vector (index) of struct ind and one vector for only storing ID for searchging faster purpose
	while (getline(inFile, str)) {
		m = 0;
		tmp = "";
		for (string::const_iterator i = str.begin(); i != str.end(); ++i) {
			if (*i != delim && *i != '\n' && i != str.end()) {
				tmp += *i;
			}
			else {
				if (m == 0 | m == 3 | m == 4) //  the index 0, 3,4  correspond to index, azimuth, and elevation angle in File lsit2016_angl.txt
				{
					tempVec.push_back(stof(tmp));
				}
				tmp = "";
				m++;
			}
		}

		tempStruct.ID = (int)tempVec[0];
		tempStruct.solarAzimuth = tempVec[1];
		tempStruct.solarElev = tempVec[2];
		tempVec.clear();

		index.push_back(tempStruct);
		sceneID.push_back(tempStruct.ID);

	}
	inFile.close();

	// the following section is to look up each pixel index stored in indexValue and compared it with the index in sceneID
	//if found, assign equivalent fields in the vector of index to aziuth angle and elevation angle
	vector<int>::iterator indx;
	int pos;
	for (long int i = 0; i < rows * cols; i++)
	{
		indx = lower_bound(sceneID.begin(), sceneID.end(), indexValue[i]); //only support sorted integer

		pos = indx - sceneID.begin();
		if (indx == sceneID.end() || *indx != indexValue[i])
		{
			angleSolarAzm[i] = -1000; // nodata
			angleSolarZen[i] = -1000;//nodata
		}
		else
		{
			angleSolarAzm[i] = (short)(index[pos].solarAzimuth * 100); /// the output result multiplied by 100
			angleSolarZen[i] = (short)((90 - index[pos].solarElev) * 100);/// the output result multiplied by 100
		}

	}
	delete[] indexValue;

	//	save solar azimuth angle
	string outputSolar_azimuth = path + startName + "solar_azimuth.raw";
	ofstream outfile(outputSolar_azimuth, ios::binary | ios::out | ios::trunc);
	outfile.write(reinterpret_cast<char*>(angleSolarAzm), sizeof(short) * rows * cols);
	outfile.close();
	delete[] angleSolarAzm;
	//save solar zenith angle
	string outputSolar_zenith = path + startName + "solar_zenith.raw";
	ofstream outfile3(outputSolar_zenith, ios::binary | ios::out | ios::trunc);
	outfile3.write(reinterpret_cast<char*>(angleSolarZen), sizeof(short) * rows * cols);
	outfile3.close();
	delete[] angleSolarZen;
}