#include <fstream>
#include <string>
#include <iostream>
#include <vector>
#include "Network.h"
#include "BioVARboundingbox.h"
#include "Convexhull.h"

using namespace std;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Description: The biophysical wrapper class include the interface to access Net, convexhull, bioVarboundingbox
//
// Revision history:    2020-Feb-21    Gang Hong    Initial Creation
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

class BioPhy
{
public:
	BioPhy(const char* filepath); // filepath: a file inlcudes for all parameter file names including full path 

	vector<Network> net;  // a vector storing objects of class Network
	vector<Network> unNet;  // a vector storing objects of class Network uncertainties
	vector <BioVARboundingbox> bioVAR; // a vector storing objects of class BioVARboundingbox
	vector <Convexhull> convex; // a vecotr storing objects of class Convechull

		//functions to get varibles from class Network
	vector<vector<float>> getinpSlope();
	vector<vector<float>> getinpOffset();
	vector<float> getoutSlope();
	vector<float> getoutOffset();

	// functions to get varibles from class BioVARboundingbox
	vector<float>  getToleranceBio();
	vector<float>  getpMin();
	vector<float>  getpMax();
	
	// functions to get varibles from class Convexhull
	int getStep();
	float getTolerance();
	vector<vector<float>> getExtreme();
	vector<long long> getUCLref();
	//vector<vector<float>> getGrid();



};

BioPhy::BioPhy(const char* filepath) {
	try
	{
		ifstream inFile(filepath);
		string str;
		///initialize 5 neural neworks for 5 biophysical parameters 
		for (int i = 0; i < 5; i++)
		{
			getline(inFile, str);
			net.push_back(Network({ 8, 5, 1 }, str.c_str()));
		}
		///initialize 5 uncertainty neural neworks for 5 biophysical parameters 
		for (int i = 0; i < 5; i++)
		{
			getline(inFile, str);
			unNet.push_back(Network({ 8, 5, 1 }, str.c_str()));
		}
		//initialize BioVARboundingbox variables corresponding to 5 biophysical parameters 
		for (int i = 0; i < 5; i++)
		{
			getline(inFile, str);
			bioVAR.push_back(BioVARboundingbox(str.c_str()));
		}
		//initialize convex instance
		getline(inFile, str);
		convex.push_back(Convexhull(str.c_str()));
	}
	catch (exception& e)
	{
		cout << e.what() << '\n';
	}
}

//get alll Tolerance value from BioVARboundingbox
vector<float> BioPhy::getToleranceBio() {
	vector<float> result;

	for (int i = 0; i < 5; i++)
		result.push_back(bioVAR[i].getToleranceBio());
	return result;
}
//get all pMin value from BioVARboundingbox
vector<float> BioPhy::getpMin() {
	vector<float> result;
	for (int i = 0; i < 5; i++)
		result.push_back(bioVAR[i].getpMin());
	return result;
}
//get all pMax value from BioVARboundingbox
vector<float> BioPhy::getpMax() {
	vector<float> result;
	for (int i = 0; i < 5; i++)
		result.push_back(bioVAR[i].getpMax());
	return result;
}
// get all inpSlope from neural network structure
vector<vector<float>> BioPhy::getinpSlope() {
	vector<vector<float>> result;
	for (int i = 0; i < 5; i++)
			result.push_back(net[i].getinpSlope());
	for (int i = 0; i < 5; i++)
		result.push_back(unNet[i].getinpSlope());

	return result;

}
// get all inpOffset from neural network structure
vector<vector<float>> BioPhy::getinpOffset() {
	vector<vector<float>> result;
	for (int i = 0; i <5; i++)
		result.push_back(net[i].getinpOffset());

	for (int i = 0; i < 5; i++)
		result.push_back(unNet[i].getinpOffset());
	return result;


}
// get all outSlope from neural network structure
vector<float> BioPhy::getoutSlope()
{
	vector<float> result;
	for (int i = 0; i < 5; i++)
		result.push_back(net[i].getoutSlope());

	for (int i = 0; i < 5; i++)
		result.push_back(unNet[i].getoutSlope());
	return result;
}

// get all outOffset from neural network structure
vector<float> BioPhy::getoutOffset()
{
	vector<float> result;
	for (int i = 0; i < 5; i++)
		result.push_back(net[i].getoutOffset());

	for (int i = 0; i < 5; i++)
		result.push_back(unNet[i].getoutOffset());
	return result;

}
//get Step from Convexhull class
int BioPhy::getStep() {
	return convex[0].getStep();

}
//get Tolerance from Convexhull class
float BioPhy::getTolerance() {

	return convex[0].getTolerance();
}
//get Extreme from Convexhull class
vector<vector<float>>BioPhy::getExtreme() {
	return convex[0].getExtreme();

}
//get UCLref from Convexhull class
vector<long long> BioPhy::getUCLref() {

	return convex[0].getUCLref();
}
//get Grid from Convexhull class
//vector<vector<float>> BioPhy::getGrid() {
//
//	return convex[0].getGrid();
//}
