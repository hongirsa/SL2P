#include "Network.h"
using namespace std;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Description: Neural Network CPP file.
//
// Revision history:    Omar Aflak   initial creation
// Revision history:    2020-Jan-10    Gang Hong    
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Network::Network(vector<int> neurons, const char* filepath)
{
	// initialize the class variable
	this->hiddenLayersCount = neurons.size() - 2;
	netInput = vector<Matrix<float> >(hiddenLayersCount + 2);
	netWeight = vector<Matrix<float> >(hiddenLayersCount + 1);
	netBias = vector<Matrix<float> >(hiddenLayersCount + 1);

	for (int i = 0; i < neurons.size() - 1; i++)
	{
		netWeight[i] = Matrix<float>(neurons[i], neurons[i + 1]);
		netBias[i] = Matrix<float>(1, neurons[i + 1]);

	}
	// load network parameters 
	loadNetworkParams(filepath);

}

Matrix<float> Network::computeOutput(vector<float> input)
{
	netInput[0] = Matrix<float>({ input }); // row matrix
	for (int i = 1; i < hiddenLayersCount + 2; i++)
	{
		if (i == 1) {
			netInput[i] = netInput[i - 1].dot(netWeight[i - 1]).add(netBias[i - 1]).applyFunction(sigmoid);
		}
		else {
			netInput[i] = netInput[i - 1].dot(netWeight[i - 1]).add(netBias[i - 1]);//output layer: the transfer function is linear
		}
	}

	return  netInput[hiddenLayersCount + 1];
}

void Network::loadNetworkParams(const char* filepath)
{
	ifstream inFile(filepath);
	if (inFile.is_open()) {
		string str;
		getline(inFile, str, '\0');
		inFile.close();
		vector<float> tempVec;
		string tmp;
		const char delim = '\t';
		for (string::const_iterator i = str.begin(); i != str.end(); ++i) {
			if (*i != delim && *i != '\n' && i != str.end()) {
				tmp += *i;
			}
			else {
				tempVec.push_back(stof(tmp));
				tmp = "";
			}
		}
		size_t temp1 = (int)tempVec[0];
		for (size_t i = 1; i < temp1 + 1; i++)
			inpSlope.push_back(tempVec[i]);

		size_t temp2 = (int)tempVec[temp1 + 1];
		for (size_t i = temp1 + 2; i < (temp1 + temp2 + 2); i++)
			inpOffset.push_back(tempVec[i]);

		int ii = 0;

		outSlope = tempVec[74];
		outOffset = tempVec[76];

		int height = netWeight[0].getHeight();
		int width = netWeight[0].getWidth();


		for (int h = 0; h < height; h++)
		{
			for (int w = 0; w < width; w++)
			{

				netWeight[0].put(h, w, *(tempVec.begin() + 19 + ii));
				ii++;
			}
		}

		height = netWeight[1].getHeight();
		width = netWeight[1].getWidth();
		ii = 0;
		for (int h = 0; h < height; h++)
		{
			for (int w = 0; w < width; w++)
			{

				netWeight[1].put(h, w, *(tempVec.begin() + 66 + ii));
				ii++;
			}
		}

		height = netBias[0].getHeight();
		width = netBias[0].getWidth();

		ii = 0;
		for (int w = 0; w < width; w++)
		{
			for (int h = 0; h < height; h++)
			{

				netBias[0].put(h, w, *(tempVec.begin() + 60 + ii));
				ii++;
			}
		}

		height = netBias[1].getHeight();
		width = netBias[1].getWidth();
		ii = 0;
		for (int h = 0; h < height; h++)
		{
			for (int w = 0; w < width; w++)
			{

				netBias[1].put(h, w, *(tempVec.begin() + 72 + ii));
				ii++;
			}
		}
	}
	else {
		cout << "Unable to open network file";
		return;
	}
}


float Network::sigmoid(float x)
{
	return 2 / (1 + exp(-2 * x)) - 1;  //Y=Tansig(x) = 2/(1+exp(-2x))-1
}


vector<float> Network::getinpSlope()
{
	return inpSlope;
}
vector<float> Network::getinpOffset() {
	return inpOffset;
}
float Network::getoutSlope() {
	return outSlope;
}
float Network::getoutOffset() {
	return outOffset;
}