#include "Convexhull.h"
#include <vector>
#include <fstream>
#include <string>
#include<iostream>
#include<algorithm>

using namespace std;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Description: Class convexhull to access parameters Step, tolerance, Extreme and Grid
//
// Revision history:    2020-Jan-10    Gang Hong    Initial Creation
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Convexhull::Convexhull(const char* filepath)
{
	loadParams(filepath);
}

void Convexhull::loadParams(const char* filepath)
{
	ifstream inFile(filepath);
	if (inFile.is_open()) {
		string str;
		getline(inFile, str, '\0');
		inFile.close();
		vector<double> tempVec; //for reading all elemenent in one line
		string tmp;
		const char delim = '\t';
		for (string::const_iterator i = str.begin(); i != str.end(); ++i) {
			if (*i != delim && *i != '\n' && i != str.end()) {
				tmp += *i;
			}
			else {
				tempVec.push_back(stod(tmp));
				tmp = "";
			}
		}
		vector<float> extreme;
		//vector<float> grid; // in this case, calculated 
		vector<long long> temp_ref; 
		//float tolerance;
		//float step;
		for (size_t i = 1; i < 11; i++)
			extreme.push_back(tempVec[i]);
		setStep((int)tempVec[14]);
		setTolerance(tempVec[12]);
	//	grid = { tempVec.begin() + 16, tempVec.end() };
		temp_ref = { tempVec.begin() + 16, tempVec.end() };
		setUCLref(temp_ref);
	//	setGrid(grid);
		setExtreme(extreme);
	//	calUCLref(grid2D);
		
	}
	else {
		cout << "Unable to open convexhull file";
		return;
	}

}
//vector<vector<float>> Convexhull::getGrid() {
//
//	return grid2D;
//}
//void Convexhull::setGrid(vector<float> temp) {
//
//	grid2D = vector<vector<float> >(914, vector<float>(5, 0));
//	int ii = 0;
//	for (int ww = 0; ww < 5; ww++)
//	{
//		for (int hh = 0; hh < 914; hh++)
//		{
//			grid2D[hh][ww] = *(temp.begin() + ii);
//			ii++;
//		}
//	}
//
//}
int Convexhull::getStep() {
	return step;
}
void Convexhull::setStep(int temp) {
	step = temp;

}
float Convexhull::getTolerance() {
	return tolerance;
}
void Convexhull::setTolerance(float temp) {
	tolerance = temp;

}
vector<vector<float>> Convexhull::getExtreme() {
	return extreme2D;
}
void Convexhull::setExtreme(vector<float> extreme) {

	extreme2D = vector<vector<float>>(2, vector<float>(5, 0)); //2 dimension
	int ii = 0;
	for (int ww = 0; ww < 5; ww++)
	{
		for (int hh = 0; hh < 2; hh++)
		{
			extreme2D[hh][ww] = *(extreme.begin() + ii);
			ii++;
		}
	}
}

//void Convexhull::calUCLref(vector<vector<float>> temp) {
//
//	long tempSum;
//	for (int i = 0; i < temp.size(); i++)
//	{
//		tempSum = 0;
//		for (int j = 0; j < temp[0].size(); j++)
//		{
//			tempSum = tempSum + temp[i][j] * pow(100, j);
//		}
//
//		UCL_ref.push_back(tempSum);
//	}
//
//	//sorted UCL_ref
//	sort(UCL_ref.begin(), UCL_ref.end(), [](const long & l, const long& r) {return l < r; });
//
//}

vector<long long > Convexhull::getUCLref() {
	return UCL_ref;
}

void Convexhull::setUCLref(vector<long long> temp) {

	UCL_ref = temp;
	sort(UCL_ref.begin(), UCL_ref.end(), [](const long long & l, const long long & r) {return l < r; });
}

