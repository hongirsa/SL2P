
#include <fstream>
#include <string>
#include<iostream>
#include <vector>
using namespace std;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Description: class bioVarboundingbox to access parameter, pMin, pMax, Tolerance
//
// Revision history:    2020-Jan-10    Gang Hong    Initial Creation
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class BioVARboundingbox
{
public:
	BioVARboundingbox(const char* filepath);  // initializing a convex hull through reading a file
	float getToleranceBio();
	void setpMin(float temp);
	void setpMax(float temp);
	void setTolerance(float temp);
	float getpMin();
	float getpMax();
	
	void loadParams(const char* filepath);
	

private:
	float pMin, pMax, toleranceBio;

};

BioVARboundingbox::BioVARboundingbox(const char* filepath) {

	loadParams(filepath);
}

void BioVARboundingbox::loadParams(const char* filepath) {

	ifstream inFile(filepath);
	if (inFile.is_open()) {
		string str;
		getline(inFile, str, '\0');
		inFile.close();
		vector<float> tempVec; //for reading all elemenent in one line
		string tmp;
		const char delim = '\t';
		for (string::const_iterator i = str.begin(); i != str.end(); ++i) {
			if (*i != delim && *i != '\n' && i != str.end()) {
				tmp += *i;
			}
			else {
				tempVec.push_back(stof(tmp));
				tmp = "";
			}
		}
		
		setpMin(tempVec[1]);
		setpMax(tempVec[3]);
		setTolerance(tempVec[5]);
		
	}
	else {
		cout << "Unable to open convexhull file";
		return;
	}
}

float BioVARboundingbox::getToleranceBio() {
	return toleranceBio;
}
void BioVARboundingbox::setpMin(float temp) {
	pMin = temp;
}
void BioVARboundingbox::setpMax(float temp){
	pMax = temp;
}
void BioVARboundingbox::setTolerance(float temp) {
	toleranceBio = temp;
}
float BioVARboundingbox::getpMin() {
	return pMin;
}
float BioVARboundingbox::getpMax() {
	return pMax;
}
