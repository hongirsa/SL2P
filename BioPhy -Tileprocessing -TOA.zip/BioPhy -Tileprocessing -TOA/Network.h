#ifndef DEF_NETWORK
#define DEF_NETWORK

#include <vector>
#include <fstream>
#include <cmath>
#include <time.h>
#include <stdlib.h>

#include "Matrix.h"
using namespace std;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Description: Neural Network head file
//
// Revision history:    Omar Aflak   initial creation
// Revision history:    2020-Jan-10    Gang Hong    
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Network
{
public:
	Network(std::vector<int> neurons, const char* filepath);
	Matrix<float> computeOutput(std::vector<float> input);
	void loadNetworkParams(const char* filepath);

	std::vector<Matrix<float> > netWeight;
	std::vector<Matrix<float> > netBias;	
	
	vector<float> getinpSlope();	
	vector<float> getinpOffset();
	float getoutSlope();
	float getoutOffset();
	

private:
	std::vector<Matrix<float> > netInput;
	int hiddenLayersCount;
	static float sigmoid(float x);
	vector<float> inpSlope;
	vector<float> inpOffset;
	float outSlope;
	float outOffset;
};

#endif
